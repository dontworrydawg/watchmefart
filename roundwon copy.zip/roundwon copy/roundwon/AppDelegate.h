//
//  AppDelegate.h
//  roundwon
//
//  Created by Ber Jr on 2016-08-22.
//  Copyright © 2016 Ber Jr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

