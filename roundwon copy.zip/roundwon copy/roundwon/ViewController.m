//
//  ViewController.m
//  roundwon
//
//  Created by Ber Jr on 2016-08-22.
//  Copyright © 2016 Ber Jr. All rights reserved.
//

#import "ViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
@import WatchConnectivity;

@interface ViewController () <WCSessionDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *bellAnimation;
@property (nonatomic) IBOutlet UISlider *roundLengthSlider;
@property (nonatomic) IBOutlet UISlider *totalRoundsSlider;
@property (nonatomic) IBOutlet UISlider *restLengthSlider;
@property (nonatomic, assign) int counter;
@property (weak, nonatomic) IBOutlet UILabel *roundLengthDescriptionLabel;
@property (weak, nonatomic) IBOutlet UILabel *roundLengthLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalRoundsDescriptionLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalRoundsLabel;
@property (weak, nonatomic) IBOutlet UILabel *restLengthDescriptionLabel;
@property (weak, nonatomic) IBOutlet UILabel *restLengthLabel;
@property (nonatomic) WCSession* watchSession;
@end

@implementation ViewController
{
    AVAudioPlayer *player;
    AVAudioPlayer *player2;
    AVAudioPlayer *player3;
    NSString *ringBellMessage;
    UIImage *image1;
    UIImage *image2;
    NSArray <UIImage*> *animationImages;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    image1 = [UIImage imageNamed:@"image1.png"];
    image2 = [UIImage imageNamed:@"image2.png"];
    [self.bellAnimation setImage:image1];
    animationImages = [NSArray arrayWithObjects:image1,image2, nil];
    [self.bellAnimation setAnimationImages:animationImages];
    [self initBellSoundPlayers];
    
    if([WCSession isSupported]){
        self.watchSession = [WCSession defaultSession];
        self.watchSession.delegate = self;
        [self.watchSession activateSession];
    }
    
    [_restLengthSlider setHidden:YES];
    [_restLengthLabel setHidden:YES];
    [_restLengthDescriptionLabel setHidden:YES];
    // Do any additional setup after loading the view, typically from a nib.
    NSThread* senderThread = [[NSThread alloc] initWithTarget:self selector:@selector(senderLoop) object:nil];
    [senderThread start];
}

- (void)initBellSoundPlayers{
    NSString *soundFilePath;
    soundFilePath = [NSString stringWithFormat:@"%@/BoxingBell1Ring.mp3", [[NSBundle mainBundle]resourcePath] ] ;
    NSURL *soundFileURL = [NSURL fileURLWithPath:soundFilePath];
    player = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL
                                                    error:nil];
    player2 = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL
                                                     error:nil];
    player3 = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL
                                                     error:nil];
}

- (void)ringBellSoundStart{
    [player play];
    [self animateBell];
    [NSThread sleepForTimeInterval:0.7];
    [player2 play];
    [self animateBell];
}

- (void)ringBellSoundEnd{
    [player play];
    [self animateBell];
    [NSThread sleepForTimeInterval:0.5];
    [player2 play];
    [self animateBell];
    [NSThread sleepForTimeInterval:0.5];
    [player3 play];
    [self animateBell];
}

-(void)animateBell{
    [self.bellAnimation setAnimationDuration:0.2];
    [self.bellAnimation setAnimationRepeatCount:1];
    [self.bellAnimation startAnimating];
    
}

- (void)senderLoop{
    while( 1 )
    {
        [self sendToWatch];
        [NSThread sleepForTimeInterval:0.3];
    }
}

- (IBAction)roundLength:(id)sender {
    //Here we are rounding by 30 seconds
    [sender setValue:(round(((_roundLengthSlider.value)/0.5))*0.5) animated:NO];
    if(_roundLengthSlider.value < 0.334){
        [sender setValue:0.334 animated:NO];
    }
    else if(_roundLengthSlider.value < 0.5)
    {
        [sender setValue:0.5 animated:NO];
    }

    NSString *timeString = [self getTimeString:_roundLengthSlider.value];
    [_roundLengthLabel setText:timeString];

}

- (void)sendToWatch {
    NSDictionary *applicationData = [[NSDictionary alloc] initWithObjects:@[
                                        [NSString stringWithFormat:@"%f",_roundLengthSlider.value],
                                        [NSString stringWithFormat:@"%d",(int)_totalRoundsSlider.value],
                                        [NSString stringWithFormat:@"%f",_restLengthSlider.value]]

                                                          forKeys:@[@"roundLength",
                                                                    @"totalRounds",
                                                                    @"restLength"]];

    
    
    [[WCSession defaultSession] sendMessage:applicationData
                               replyHandler:^(NSDictionary *reply) {
                                   //handle reply form Iphone app here
                               }
                               errorHandler:^(NSError *error) {
                                   //catch any errors here
                               }
     ];
}

- (void)session:(nonnull WCSession *)session didReceiveMessage:(nonnull NSDictionary *)message
   replyHandler:(nonnull void (^)(NSDictionary * __nonnull))replyHandler {
    ringBellMessage = [message objectForKey:@"ringBell"];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        //[self.roundFinished setText:eMessage];
        if([ringBellMessage isEqualToString:@"1"])
        {
            [self ringBellSoundEnd];
        }
        else if ([ringBellMessage isEqualToString:@"0"])
        {
            [self ringBellSoundStart];
        }
    });
}

- (NSString*)getTimeString:(float)sliderValue {
    NSString *minuteString = [NSString stringWithFormat:@"%d",(int)floor(sliderValue)];
    int minuteInt = (int)floor(sliderValue);
    NSString *secondsString = [NSString stringWithFormat:@"%d",abs((int)((sliderValue - minuteInt)*60))];
    if(secondsString.intValue < 10)
    {
        secondsString = [NSString stringWithFormat:@"0%@",secondsString];
    }
     
    NSString *timeString = [NSString stringWithFormat:@"%@:%@",minuteString,secondsString];
    return timeString;
}

- (IBAction)totalRounds:(id)sender {
    //Here we are rounding by 1 round
    [sender setValue:(round(_totalRoundsSlider.value)) animated:NO];
    NSString *stringTotalRounds = [NSString stringWithFormat:@"%d",(int)_totalRoundsSlider.value];
    
    if(_totalRoundsSlider.value < 1)
    {
        [sender setValue:1 animated:NO];
        stringTotalRounds = @"1";
    }
    
    if(_totalRoundsSlider.value < 2)
    {
        [_restLengthSlider setHidden:YES];
        [_restLengthLabel setHidden:YES];
        [_restLengthDescriptionLabel setHidden:YES];
    }
    else
    {
        [_restLengthSlider setHidden:NO];
        [_restLengthLabel setHidden:NO];
        [_restLengthDescriptionLabel setHidden:NO];
    }
    
    [_totalRoundsLabel setText:stringTotalRounds];
}

- (IBAction)restLength:(id)sender {
    //Here we are rounding by 5 seconds
    float oneOverTwelve = 0.083333333;
    [sender setValue:(round(((_restLengthSlider.value)/oneOverTwelve))*oneOverTwelve) animated:NO];
    
    NSString *timeString = [self getTimeString:_restLengthSlider.value];
    [_restLengthLabel setText:timeString];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)emergencyReset:(id)sender {
    [self ringBellSoundEnd];
    NSString *eMessage = [NSString stringWithFormat:@"%s","Emergency Stop"];
    NSDictionary *applicationData = [[NSDictionary alloc] initWithObjects:@[eMessage]
                                                                  forKeys:@[@"eReset"]];
    
    [[WCSession defaultSession] sendMessage:applicationData
                               replyHandler:^(NSDictionary *reply) {
                                   //handle reply form Iphone app here
                               }
                               errorHandler:^(NSError *error) {
                                   //catch any errors here
                               }
     ];
    
}



@end
