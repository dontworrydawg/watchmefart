//
//  InterfaceController.m
//  roundwonwatch Extension
//
//  Created by Ber Jr on 2016-08-22.
//  Copyright © 2016 Ber Jr. All rights reserved.
//

#import "InterfaceController.h"
@import WatchConnectivity;


@interface InterfaceController() <WCSessionDelegate>

@property (weak, nonatomic) IBOutlet WKInterfaceTimer *timer;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *roundFinished;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *beginRoundButton;
@end


@implementation InterfaceController
{
    NSString *eMessage;
    NSString *roundLengthString;
    NSString *restLengthString;
    NSString *totalRoundsString;
    int roundLength;
    int totalRounds;
    int roundsLeft;
    int restLength;
    NSTimer *realTimer;
    int seconds;
    BOOL fightOn;
    BOOL roundOn;
}

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    roundLength = 180;
    fightOn = NO;
    roundOn = NO;
}

- (void)session:(nonnull WCSession *)session didReceiveMessage:(nonnull NSDictionary *)message
   replyHandler:(nonnull void (^)(NSDictionary * __nonnull))replyHandler {
    eMessage = [message objectForKey:@"eReset"];
    roundLengthString = [message objectForKey:@"roundLength"];
    restLengthString = [message objectForKey:@"restLength"];
    totalRoundsString = [message objectForKey:@"totalRounds"];
 
    dispatch_async(dispatch_get_main_queue(), ^{
        //[self.roundFinished setText:eMessage];
        if([eMessage isEqualToString:@"Emergency Stop"])
        {
            [self resetRound];
        }
        if(!fightOn){
            [self setupRound];
            [self.roundFinished setText:[NSString stringWithFormat:@"# Rounds: %@",totalRoundsString]];
        }
    });
}

- (void)willActivate {
    // This method is called when watch view controller is about t be visible to user
    [super willActivate];
    
    [self setupRound];
    
    if ([WCSession isSupported])
    {
        WCSession* session = [WCSession defaultSession];
        session.delegate = self;
        [session activateSession];
    }
}



- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

- (IBAction)startRound {
    [self setupFight];
    [self setupRound];
    [self showRoundText];
    [self.timer start];
    [self startRealTimer];
    [self.beginRoundButton setEnabled:NO];
    [self sendToPhoneRingStart];
    fightOn = YES;
    roundOn = YES;
}

- (void)startRealTimer{
    realTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(runLoop) userInfo:nil repeats:YES];
}

- (void)setupFight {
    totalRounds = totalRoundsString.intValue;
    roundsLeft = totalRoundsString.intValue;
    roundLength = (int)(roundLengthString.floatValue*60);
    restLength = (int)(restLengthString.floatValue*60);
}

- (void)setupRound {
    roundLength = (int)(roundLengthString.floatValue*60);
    seconds = 0;
    [self.timer setDate: [NSDate dateWithTimeIntervalSinceNow:(roundLength + 1)]];
    [self.roundFinished setText:@""];
}

- (void)setupRest {
    restLength = (int)(restLengthString.floatValue*60);
    seconds = 0;
    [self.timer setDate: [NSDate dateWithTimeIntervalSinceNow:(restLength + 1)]];
    [self.roundFinished setText:@"Rest Time"];
}

- (void)showRoundText {
    [self.roundFinished setText:[NSString stringWithFormat:@"Round %d of %d",(totalRounds - roundsLeft + 1),totalRounds]];
}

- (void)runLoop{
    
    if(seconds == roundLength && roundOn)
    {
        [self endRound];
        if(!fightOn){
            [realTimer invalidate];
        }
    }
    else if(seconds == restLength && !roundOn)
    {
        [self setupRound];
        [self.timer start];
        [self showRoundText];
        roundOn = YES;
        [self sendToPhoneRingStart];
    }
    
    seconds ++;
}

- (void)vibrateWatch{
    [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeSuccess];
}

- (void)endRound{
    [self vibrateWatch];
    roundOn = NO;
    const int LASTROUND = 1;
    if(roundsLeft == LASTROUND)
    {
       fightOn = NO;
       [self.roundFinished setText:@"Fight Finished!"];
       [self sendToPhoneRingEnd];
       [self.beginRoundButton setEnabled:YES];
    }
    else{
        roundsLeft -= 1;
        [self sendToPhoneRingEnd];
        [self.roundFinished setText:@"Round Finished!"];
        [self setupRest];
    }
    
}

- (void)resetRound{
    fightOn = NO;
    roundOn = NO;
    seconds = 0;
    [realTimer invalidate];
    [self.beginRoundButton setEnabled:YES];
    [self setupRound];
    [self.timer stop];
    
}

- (void)sendToPhoneRingStart {
    NSDictionary *applicationData = [[NSDictionary alloc] initWithObjects:@[@"0"] forKeys:@[@"ringBell"]];
    
    [[WCSession defaultSession] sendMessage:applicationData
                               replyHandler:^(NSDictionary *reply) {
                                   //handle reply form Iphone app here
                               }
                               errorHandler:^(NSError *error) {
                                   //catch any errors here
                               }
     ];
}

- (void)sendToPhoneRingEnd {
    NSDictionary *applicationData = [[NSDictionary alloc] initWithObjects:@[@"1"] forKeys:@[@"ringBell"]];
    
    [[WCSession defaultSession] sendMessage:applicationData
                               replyHandler:^(NSDictionary *reply) {
                                   //handle reply form Iphone app here
                               }
                               errorHandler:^(NSError *error) {
                                   //catch any errors here
                               }
     ];
}@end



