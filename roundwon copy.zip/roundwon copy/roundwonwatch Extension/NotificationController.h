//
//  NotificationController.h
//  roundwonwatch Extension
//
//  Created by Ber Jr on 2016-08-22.
//  Copyright © 2016 Ber Jr. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface NotificationController : WKUserNotificationInterfaceController

@end
